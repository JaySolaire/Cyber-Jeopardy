#1
while(1):
	pass

#2
while(true):
	pass
	
#3
a = 1
while(a > 0):
	pass

#4
a = 100
while (a):
	pass

